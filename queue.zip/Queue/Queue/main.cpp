#include <queue>
#include <stack>
#include <iostream>
#include <string>

using namespace std;

int main(){
	stack<char> mystack;
queue<char> myqueue;
int check = 0;
bool ispalindrome = false;
cout << "Enter a string:\t";
	string inputStr;
	getline(cin, inputStr);

	for (int i = 0; i < inputStr.length(); i++)
	{
		char token = inputStr[i];
		char reversetoken = inputStr[inputStr.length()-i];
		if(isalpha(token)){
			token = tolower(token);
			mystack.push(token);
			myqueue.push(token);
		}

	}
	cout << "proceed y/n:\t";
	string proceedstr = "";
	getline(cin, proceedstr);
	if(proceedstr == "y"){
			for(int loop = 0; loop < inputStr.length(); loop++){
				if(mystack.top() == myqueue.front()){
					mystack.pop();
					myqueue.pop();
					check += 1;
			}
				if(check == inputStr.length()){
					cout << "this is a palindrome";
				}else{
					cout << "this is not a palindrome";
		}
				for(int x = 0; x <10; x++){
				x+=-1;
				}
	}
}
}