#include <iostream>
#include <ctime>
#include "header.h"
using namespace std;

struct node
{
	int data;
	node *link;
};

void reverseList (node *p_Ptr)
{
	if(p_Ptr != NULL){
		reverseList(p_Ptr->link);
		cout << p_Ptr->data << ' ';
	}

}

int main()
{
int x[10];

node *tempListPtr = NULL;

node *headPtr = NULL;

node *tailPtr = NULL;
	srand(static_cast<int>(time(0)));
	for (int i = 0; i < 10; i++)
	{
		x[i] = rand();
		tempListPtr = new node;
		tempListPtr -> data = x[i];
		tempListPtr -> link = NULL;
		
		if (i == 0)
			headPtr = tailPtr = tempListPtr;
		else 
		{		
			tailPtr -> link = tempListPtr;
			tailPtr = tempListPtr;
		}
	}

	tempListPtr = headPtr;
	while (tempListPtr != NULL)
	{
		cout << tempListPtr -> data << ' '; 
		tempListPtr = tempListPtr -> link;
	}
	
	cout << endl;
	reverseList (headPtr);

	cout << endl;
	return 0;
}