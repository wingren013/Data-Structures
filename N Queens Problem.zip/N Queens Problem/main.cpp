#include<stack>;
#include<iostream>;
//#include"Header.h"
using namespace::std;

struct  pushvar{
	int row;
	int column;
};


struct board{
	int n;
};

int main(){
  pushvar queenvar;
  queenvar.row = 1;
  queenvar.column = 1;
  board Nboard;
  Nboard.n = 5;
  int d = 5;
stack<pushvar> queenstack;
stack<pushvar> prevstack;
stack<pushvar> tempstack;

pushvar y;
int loop = 0;
int track = 0;
int end = 0;
  for(int fill = 0; fill<(d); fill++){
	  fill--;
	  if(!queenstack.empty() == true){
		  queenstack.push(queenvar);
		  fill++;
		  queenvar.row += 1;
	  }else{
		  for(int x = 0; x < 1;){
			y = prevstack.top();
			if(y.row == queenvar.row || y.column == queenvar.column || y.row-y.column == queenvar.row-queenvar.column || y.row-y.column-2 == queenvar.row-queenvar.column-2){
				queenvar.column += 1;
			}else{
				loop++;
				if(loop==d-(d-1)+queenvar.row-2){end = 1;}
				if(loop<d-(d-1)+queenvar.row-2){
				tempstack.push(prevstack.top());
				prevstack.pop();
				track++;
				}
			}
			  if(end == 1){
  queenstack.push(queenvar);
  fill++;
  loop = 0;
  for(int q=1; track > 0;){
  prevstack.push(tempstack.top());
  tempstack.pop();
  track--;
  if(track == 0){x=1; fill++; queenvar.row++;}
}
}
}
}
}

  for(int i = 0; i<10; i++){cout<<"T"; i--;}
}
