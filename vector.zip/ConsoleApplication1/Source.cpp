#include<iostream>;
#include<vector>;
#include"Header.h";
#include<string>;
using namespace std;


int main(){
	vector<person> people;
	string listsize;
	string get;

	cout<<"enter number of people ";
	getline(cin, listsize);
	int mysize = stoi(listsize);
	for(int i =0; i<mysize; i++){
		cout<<"enter the person's name ";
	getline(cin, get);
	person newperson;
	newperson.name = get;
	cout<<"enter the persons age ";
			getline(cin, get);
	int myint = stoi(get);
	newperson.age = myint;
	people.push_back(newperson);
	}
	cout<<"number of people ";
	cout<<people.capacity();
	for (int red = 0; red < people.capacity(); red++){
		for (int black = people.capacity()-1; black > red; black--){
			cout<<black;
		if(people[black].age<people[black-1].age){
		person x = people[black];
			people[black] = people[black-1];
			people[black-1] = x;
			for(int i = 0; i < people.capacity(); i++){
			}
			cout<<

//int myArray[8];
//for (int red = 0; red <= myArray.length-1; red++){
	//for (int black = myArray.length-1; black > red; black--){
	//	if(myArray[black]<myArray[black-1]){
	//		int x = myArray[black];
//			myArray[black] = myArray[black-1];
			//myArray[black-1] = x;
		//}
	//}
//}
//return myArray;
	for(int i = 0; i <10;){};
return 0;
}

		}
	}
}