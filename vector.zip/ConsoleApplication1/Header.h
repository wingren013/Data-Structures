#include<iostream>;
#include<vector>;
using namespace std;

struct person{
	string name;
	int age;
};