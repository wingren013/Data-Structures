#include <queue>
#include <stack>
#include <iostream>
#include <string>
#include<ctime>;
#include<array>;
#include<vector>;
using namespace std;

int main(){
	queue<int> myqeue;
	queue<int> onetotwenty;
	queue<int> twentytosixty;
	queue<int> sixtyoneplus;
	int n [20];
	int store [20];
	vector<int> storetwenty [20];

	srand(static_cast<int>(time(0)));
	for(int i = 0; i < 20; i++){
			int q = 1+rand() % 100;
			myqeue.push(q);
			n[i] = q;
	}

	for(int i = 0; i < 20; i++){
		if(myqeue.front() <= 20){
			onetotwenty.push(myqeue.front());
			storetwenty[i].push_back(myqeue.front());
		}	
			store[i] = myqeue.front();
			myqeue.pop();
	}

	for(int i=0; i<20; i++){myqeue.push(store[i]);}

	for(int i = 0; i < 20; i++){
		if(myqeue.front() > 20 && myqeue.front() <= 60){
			twentytosixty.push(myqeue.front());
		}	
			store[i] = myqeue.front();
			myqeue.pop();
	}

	for(int i=0; i<20; i++){myqeue.push(store[i]);}

	for(int i = 0; i < 20; i++){
		if(myqeue.front() > 60){
			sixtyoneplus.push(myqeue.front());
		}	
			store[i] = myqeue.front();
			myqeue.pop();
	}

	cout << "the main qeue: ";
	for(int i=0; i<20; i++){
		cout << store[i];
		cout << " ";
	}
	cout << endl;
	cout << "one to twenty: ";
	int x = onetotwenty.size();
	for(int i=0; i<x; i++){
		cout << onetotwenty.front();
		cout << " ";
		onetotwenty.pop();
	}
		cout << endl;
	cout << "twenty-one to sixty: ";
	int y = twentytosixty.size();
	for(int i=0; i<y; i++){
		cout << twentytosixty.front();
		cout << " ";
		twentytosixty.pop();
	}
		cout << endl;
	cout << "sixty-one to one-hundred: ";
	int z = sixtyoneplus.size();
	for(int i=0; i<z; i++){
		cout << sixtyoneplus.front();
		cout << " ";
		sixtyoneplus.pop();
	}

	for(int i=0; i<20; i++){myqeue.push(store[i]);}
	for(int i = 0; i<10;){}
}