#include "BagVer02.h"
#include <iostream>

TheBig3Bag::TheBig3Bag()
{
	size = 0;
	capacity = 5;
	arr = new int[capacity];
}
TheBig3Bag::~TheBig3Bag(){
	delete[] arr;
}
int TheBig3Bag::getValue(int index)
{
	return *arr;
}
void TheBig3Bag::setValue(int newValue)
{
	arr[size] = newValue;
	size++;
}
void TheBig3Bag::display()
{
	for (int i = 0; i < size; i++)
		std::cout << arr[i] << ' ';
	std::cout << std::endl;
	
}

TheBig3Bag& TheBig3Bag:: operator= (const TheBig3Bag& p_source)
{
	size = p_source.size;
	capacity = p_source.capacity;
	arr = new int[capacity];
	for (int i = 0; i < size; i++)
		arr[i] = p_source.arr[i];
	return *this;
};

TheBig3Bag::TheBig3Bag(const TheBig3Bag& p_source)
{
	size = p_source.size;
	capacity = p_source.capacity;
	arr = new int[capacity];
	for (int i=0; i<size; i++)
		arr[i]=p_source.arr[i];
};
