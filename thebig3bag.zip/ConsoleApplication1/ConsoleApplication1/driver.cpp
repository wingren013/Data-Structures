#include <iostream>
#include "BagVer02.h"
using namespace std;

int main()
{
	TheBig3Bag *myBag1;
	myBag1 = new TheBig3Bag;
	myBag1 -> setValue (1);
	myBag1 -> setValue(2);
	myBag1 -> setValue(3);
	

	//Automatic assignment operator
	TheBig3Bag myBag2;
	myBag2 = *myBag1;
	

	//Automatic copy constructor
	TheBig3Bag myBag3(*myBag1);
	myBag1 -> display();
	myBag3.arr[1] = myBag2.arr[1];
	delete myBag1;
	myBag2.display();
	myBag3.display();

	cout << endl;
	
	return 0;
}