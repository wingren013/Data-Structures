class TheBig3Bag
{	 
public:
	TheBig3Bag();
	~TheBig3Bag();
	int getValue(int index);
	void setValue(int newValue);
	void display();
	int *arr;
	TheBig3Bag(const TheBig3Bag& p_source);
	TheBig3Bag& operator= (const TheBig3Bag& p_source);
private:
	int size;
	int capacity;
};
