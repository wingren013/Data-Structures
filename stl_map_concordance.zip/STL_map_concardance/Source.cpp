#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <set>
using namespace std;
int	main(){
	ifstream myfile;
	myfile.open("inputfile.txt");
	string paragraph;
	if(myfile.is_open())
	{
	while(!myfile.eof())
	{
	getline (myfile, paragraph);
	cout<< paragraph <<endl;
	};
	};


	map<string,set<int> > concordance;   //You need a space between > >  
					     //  Otherwise, it is a compile error
	set<int> mySet;     
	mySet.insert(1);
	mySet.insert(2);
	mySet.insert(3);
	std::string key = "associative";     
	concordance[key] = mySet;     
	   

	for(int i=23; i > 10;){}
	return 0;
};





























