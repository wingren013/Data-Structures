#include <stack>
#include <iostream>
using namespace::std;

struct  pushvar{
	int row;
	int column;
};


struct board{
	int n;
};